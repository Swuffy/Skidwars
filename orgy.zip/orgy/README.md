# Orgy

Svelte cheat UI sample. It's not that hard guys  
Build: `npm run build`
